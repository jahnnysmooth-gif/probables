# Git Deployment Instructions

## Step 1: Create New GitHub Repository

1. Go to https://github.com/new
2. Repository name: `streaming-bot` (or your choice)
3. Description: "Fantasy baseball streaming scout Discord bot"
4. **Important:** Choose **Private** (contains API keys in future commits)
5. **Do NOT** initialize with README, .gitignore, or license (we have these)
6. Click "Create repository"

## Step 2: Initialize Git Locally

```bash
cd /home/claude

# Initialize git repo
git init

# Add all files
git add .

# Initial commit
git commit -m "Initial commit: Streaming Bot v2.0 with Statcast, weather, lineup analysis"

# Add your GitHub repo as remote (replace with your URL)
git remote add origin https://github.com/YOUR_USERNAME/streaming-bot.git

# Push to main branch
git branch -M main
git push -u origin main
```

## Step 3: Verify Files Pushed

Your repo should now contain:
- ✅ streaming_bot_v2.py
- ✅ streaming_bot_TEST.py
- ✅ requirements.txt
- ✅ render.yaml
- ✅ .env.example
- ✅ .gitignore
- ✅ README.md
- ✅ QUICKSTART.md
- ✅ streaming_bot_README.md
- ✅ streaming_bot_ROADMAP.md

**Should NOT contain:**
- ❌ .env (sensitive credentials)
- ❌ espn_player_ids.json (large data file)

## Step 4: Deploy to Render

### Option A: Blueprint Deployment (Recommended)

1. In Render dashboard: **Blueprints** → **New Blueprint Instance**
2. Connect your GitHub account
3. Select your `streaming-bot` repository
4. Render auto-detects `render.yaml`
5. Click **"Apply"**
6. Set environment variables:
   - `STREAMING_BOT_TOKEN`
   - `STREAMING_CHANNEL_ID`
   - `STREAMING_BOT_SUMMARY`
7. Deploy

### Option B: Manual Deployment

1. Render dashboard: **New** → **Web Service**
2. Connect GitHub repo: `streaming-bot`
3. Settings:
   - **Name:** `streaming-bot`
   - **Region:** Oregon (or closest)
   - **Branch:** `main`
   - **Build Command:** `pip install -r requirements.txt --break-system-packages`
   - **Start Command:** `python streaming_bot_v2.py` (production) or `python streaming_bot_TEST.py` (testing)
4. Add environment variables (see above)
5. Create Web Service

## Step 5: Upload ESPN Player IDs

After deployment:

1. Render dashboard → Your service → **Shell** tab
2. Click **Connect**
3. Upload `espn_player_ids.json`:

**Method A: Upload via Render file browser (if available)**

**Method B: Paste JSON directly**
```bash
cat > /home/claude/espn_player_ids.json << 'JSON_END'
{paste your JSON here}
JSON_END
```

## Step 6: Test

In your Discord server:
```
!stream
```

Bot should respond within 30-60 seconds with today's streaming board.

## Future Updates

When you make changes:

```bash
# Stage changes
git add .

# Commit with descriptive message
git commit -m "Add velocity trend tracking feature"

# Push to GitHub
git push origin main
```

Render auto-deploys on every push to `main` branch.

---

## Quick Reference

**Current directory:** `/home/claude`

**Files ready to push:**
- streaming_bot_v2.py (production bot)
- streaming_bot_TEST.py (test bot)
- requirements.txt
- render.yaml
- README.md
- QUICKSTART.md
- streaming_bot_README.md
- streaming_bot_ROADMAP.md
- .env.example
- .gitignore

**Git commands:**
```bash
git init
git add .
git commit -m "Initial commit: Streaming Bot v2.0"
git remote add origin https://github.com/YOUR_USERNAME/streaming-bot.git
git branch -M main
git push -u origin main
```

Done! Your streaming bot is now deployed and will post daily at 8 AM ET.
