# Streaming Bot - Fantasy Baseball Streamer Scout

**AI-powered Discord bot that analyzes probable MLB starters under 60% rostered and delivers Start Scores with comprehensive fantasy analysis.**

## Features

✨ **Complete Day-One Feature Set:**
- 🎯 100-point scoring system across 5 weighted buckets
- 📊 Baseball Savant Statcast integration (xERA, SwStr%, hard-hit%, barrel%)
- 🌤️ Live weather forecasts tied to game time (Open-Meteo API)
- 👥 Projected lineup analysis (elite bat count, K-prone hitters)
- ⚾ Pitcher handedness detection + home/away splits
- 🤖 Claude AI beat-writer summaries with risk callouts
- 📈 ESPN ownership filtering via kona_player_info
- 🏟️ Park factors for all 30 MLB stadiums
- 🎖️ League depth recommendations (10-team, 12-team, 15-team)

## Quick Start

### 1. Clone this repo
```bash
git clone <your-repo-url>
cd streaming-bot
```

### 2. Set up environment variables

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Edit `.env` with your credentials:
```bash
STREAMING_BOT_TOKEN=your_discord_bot_token
STREAMING_CHANNEL_ID=your_discord_channel_id
STREAMING_BOT_SUMMARY=your_anthropic_api_key
OWNERSHIP_THRESHOLD=60.0
ESPN_PLAYER_IDS_PATH=/path/to/espn_player_ids.json
```

### 3. Install dependencies
```bash
pip install -r requirements.txt --break-system-packages
```

### 4. Test locally
```bash
python streaming_bot_TEST.py
```

The bot will immediately fetch today's probable starters, score them, and post to your Discord channel.

### 5. Deploy to Render

**Via Blueprint:**
1. Push this repo to GitHub
2. In Render dashboard → "Blueprints" → "New Blueprint Instance"
3. Connect your repo → Select `render.yaml`
4. Set environment variables in Render dashboard
5. Deploy

**Via Manual Setup:**
1. Render → "New" → "Web Service"
2. Connect repo
3. Build command: `pip install -r requirements.txt --break-system-packages`
4. Start command: `python streaming_bot_v2.py` (production) or `python streaming_bot_TEST.py` (testing)
5. Add environment variables
6. Deploy

## File Structure

```
streaming-bot/
├── streaming_bot_v2.py          # Production bot (runs daily 8 AM ET)
├── streaming_bot_TEST.py        # Test bot (runs immediately on startup)
├── requirements.txt              # Python dependencies
├── render.yaml                   # Render deployment config
├── .env.example                  # Environment variable template
├── .gitignore                    # Git ignore rules
├── README.md                     # This file
├── QUICKSTART.md                 # Detailed setup guide
├── streaming_bot_README.md       # Full technical documentation
└── streaming_bot_ROADMAP.md      # Future enhancement roadmap
```

## Bot Versions

### `streaming_bot_v2.py` (Production)
- Runs daily at 8:00 AM ET automatically
- Minimal console logging
- Use for long-term deployment

### `streaming_bot_TEST.py` (Testing)
- Runs immediately on startup
- Verbose console logging with emojis
- Use for testing features or on-demand `!stream` commands

## Commands

### `!stream`
Manually trigger streaming board generation.

**Usage:**
```
!stream
```

Bot fetches probable starters, calculates scores, generates AI summaries, and posts to Discord.

## Scoring System

**Total: 100 points**

1. **Skill (30 pts)** — xERA, K-BB%, SwStr%/CSW%, hard-hit%/barrel%
2. **Form (20 pts)** — Last 3 starts: ERA, K/9, BB/9
3. **Matchup (25 pts)** — Team wRC+, K%, lineup danger map
4. **Park/Weather (15 pts)** — Park factor + weather adjustments
5. **Context (10 pts)** — Home/away splits, innings depth

**Streaming Tiers:**
- 🔥 **Must-Stream** (85-100): Priority in 10-team leagues
- ✅ **Strong Stream** (75-84): Must-consider in 12-team leagues
- ⚡ **Viable Stream** (65-74): Viable in 15-team leagues
- 🤔 **Deep League Only** (55-64): Deep-league dart only
- ❌ **Avoid** (0-54): Skip in all formats

## Data Sources

All data sources are **free** and require no API keys except Anthropic:

- **MLB Stats API** — Probable starters, game logs, season stats, splits
- **Baseball Savant** (via pybaseball) — Statcast metrics (xERA, SwStr%, contact quality)
- **ESPN Fantasy API** — Ownership percentages via `kona_player_info`
- **Open-Meteo API** — Weather forecasts (temperature, wind, precipitation)
- **Anthropic API** — Claude 3.5 Haiku for AI summaries

## Cost

**Monthly: ~$0.60 - $1.00**

- Anthropic Claude Haiku: ~$0.60/month (10-15 summaries/day)
- All other APIs: Free

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `STREAMING_BOT_TOKEN` | ✅ | Discord bot token |
| `STREAMING_CHANNEL_ID` | ✅ | Discord channel ID for posts |
| `STREAMING_BOT_SUMMARY` | ✅ | Anthropic API key |
| `OWNERSHIP_THRESHOLD` | ❌ | Ownership filter (default: 60.0) |
| `ESPN_PLAYER_IDS_PATH` | ❌ | Path to ESPN player ID mapping (default: `/home/claude/espn_player_ids.json`) |

## ESPN Player IDs

The bot requires an ESPN player ID mapping file to fetch ownership data.

**Format** (`espn_player_ids.json`):
```json
{
  "660271": {"espn_id": "33039", "name": "Shane Bieber"},
  "605141": {"espn_id": "31283", "name": "Gerrit Cole"}
}
```

**Where to get it:**
- Use your existing `espn_player_ids.json` from other bots
- Or build one using ESPN's player API

**Upload to Render:**
1. Render dashboard → Your service → "Shell"
2. Upload file or paste JSON content

## Troubleshooting

### Bot not posting
- Check Discord permissions: `Send Messages`, `Embed Links`
- Verify `STREAMING_CHANNEL_ID` is correct
- Check Render logs for errors

### No pitchers under threshold
- Normal on slow slate days or when all starters are highly rostered
- Lower `OWNERSHIP_THRESHOLD` temporarily (e.g., 75.0)
- Check if games are scheduled today

### Statcast data unavailable
- May occur early season or during offseason
- Bot continues without Statcast metrics (uses ERA/WHIP instead)
- Check pybaseball connectivity

### AI summaries failing
- Verify `STREAMING_BOT_SUMMARY` API key is valid
- Check Anthropic account credit balance
- Bot uses fallback templates if Claude API fails

## Documentation

- **QUICKSTART.md** — 15-minute deployment walkthrough
- **streaming_bot_README.md** — Full technical specs and API details
- **streaming_bot_ROADMAP.md** — Future enhancement roadmap

## Contributing

This bot is built for your fantasy baseball Discord server. Feel free to:
- Modify scoring weights in `calculate_start_score()`
- Adjust ownership threshold
- Customize AI prompt in `generate_ai_summary()`
- Add new park factors or weather logic

## License

MIT License — use freely, credit appreciated.

## Support

For issues or questions:
1. Check Render logs first
2. Review troubleshooting section above
3. Verify all environment variables are set

Built with ⚾ for the fantasy baseball community.
